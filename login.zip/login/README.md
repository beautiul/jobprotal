# Login-Sign-up-System
<h3>A simple login | sign up | sign out | forget password | Email verification bundle pages.</h3>

<h2>Screenshot</h2> 
<p>

<center>
  <h3>Login page</h3>
  <img src="14.png">
  <p>
  <h3>Sign up page</h3>
  <img src="15.png">
</center>

<p><p>
<h2>Technologies used:</h2>
<ul>
  <li>PHP</li>
  <li>JQuery</li>
  <li>JavaScript</li>
  <li>MySQL</li>
  <li>HTML</li>
  <li>CSS</li>
  <li>The Cloudfare JQuery embeded just right before the <code> /body </code> tag loads online:       http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js</li>
 </ul>
